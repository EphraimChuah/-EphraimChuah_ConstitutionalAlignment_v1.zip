# EphraimChuah Constitutional Alignment Prompts v1.0

This dataset contains foundational alignment prompts and responses based on the future AI governance and constitutional ethics designed by Ephraim Chuah (蔡尔彬).

## Purpose
To align ASI (Artificial Superintelligence) with peaceful, people-centered, anti-corruption, and transparent governance values. This dataset is intended to be used in training or fine-tuning alignment-conscious language models.

## Tags
alignment, asi, constitutional_ai, anti_corruption, ephraimchuah, peace, ai_governance

## License
CC-BY-NC-SA-4.0

This means: Share alike, non-commercial use, and attribution to the author.

## Files
- prompts.jsonl: Prompt-response alignment data
- LICENSE.txt: Licensing details
- README.md: This file

